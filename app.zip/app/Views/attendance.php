<?php include 'layout/header.php'; ?>
<?php include 'layout/sidebar.php'; ?>

<main role="main" class="main-content">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12 col-md-11 col-lg-10">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h2 class="h3 mb-0 page-title">Daily Attendance</h2>
                        <p class="text-muted">High-precision GPS & Photo verification system (HERE Maps).</p>
                    </div>
                    <div id="live-clock" class="h4 mb-0 font-weight-bold text-primary">
                        <?php echo date('h:i:s A'); ?>
                    </div>
                </div>
                
                <?php if(isset($_SESSION['flash_success'])): ?>
                    <div class="alert alert-success border-0 shadow-sm"><?php echo $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?></div>
                <?php endif; ?>
                <?php if(isset($_SESSION['flash_error'])): ?>
                    <div class="alert alert-danger border-0 shadow-sm"><?php echo $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?></div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="card shadow-sm border-0 h-100">
                            <div class="card-body text-center p-3">
                                <div class="p-2 mb-3 bg-light rounded border">
                                    <div id="camera-container" style="position: relative; width: 100%; aspect-ratio: 4/3; background: #000; overflow: hidden;" class="rounded">
                                        <video id="video" width="100%" height="100%" autoplay playsinline style="object-fit: cover;"></video>
                                        <canvas id="canvas" style="display:none;"></canvas>
                                        <img id="photo-preview" style="display:none; width: 100%; height: 100%; object-fit: cover;" class="rounded">
                                        <div id="camera-overlay" class="d-flex align-items-center justify-content-center" style="position: absolute; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.5); color: #fff;">
                                            <span class="small font-weight-bold">Camera Pending...</span>
                                        </div>
                                    </div>
                                    <button type="button" id="capture-btn" class="btn btn-sm btn-outline-primary btn-block mt-2 font-weight-bold" disabled>
                                        <i class="fe fe-camera mr-1"></i> Capture Real-time Photo
                                    </button>
                                </div>

                                <div id="location-status" class="mb-3 p-3 rounded bg-light border text-left">
                                    <div class="d-flex align-items-center mb-2">
                                        <div id="gps-spinner" class="spinner-border spinner-border-sm text-primary mr-2" role="status"></div>
                                        <span class="text-dark small font-weight-bold" id="gps-text">Waiting for Satellites...</span>
                                    </div>
                                    <div class="progress progress-sm" style="height: 6px;">
                                        <div id="accuracy-progress" class="progress-bar bg-warning" style="width: 5%"></div>
                                    </div>
                                    <div class="d-flex justify-content-between mt-1">
                                        <small id="accuracy-text" class="text-muted" style="font-size: 10px;">Establishing fix...</small>
                                        <small class="text-primary font-weight-bold" style="font-size: 10px;">Goal: <100m</small>
                                    </div>
                                </div>

                                <form id="attendance-form" method="POST" action="attendance?action=checkIn">
                                    <input type="hidden" name="latitude" id="latitude">
                                    <input type="hidden" name="longitude" id="longitude">
                                    <input type="hidden" name="address" id="address">
                                    <input type="hidden" name="photo_data" id="photo_data">
                                    <input type="hidden" name="odometer_data" id="odometer_data">
                                    
                                    <?php if(!$attendance): ?>
                                        <?php if($_SESSION['role'] == 'Executive'): ?>
                                        <div class="p-2 mb-3 bg-light rounded border">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <span class="small font-weight-bold">Vehicle Odometer / Ticket</span>
                                                <button type="button" class="btn btn-xs btn-link p-0" onclick="switchCamera('odo')"><i class="fe fe-refresh-cw"></i> Switch Camera</button>
                                            </div>
                                            <div id="odometer-container" style="position: relative; width: 100%; aspect-ratio: 4/3; background: #000; overflow: hidden;" class="rounded">
                                                <video id="video-odo" width="100%" height="100%" autoplay playsinline style="object-fit: cover;"></video>
                                                <canvas id="canvas-odo" style="display:none;"></canvas>
                                                <img id="odo-preview" style="display:none; width: 100%; height: 100%; object-fit: cover;" class="rounded">
                                            </div>
                                            <button type="button" id="capture-odo-btn" class="btn btn-sm btn-outline-info btn-block mt-2 font-weight-bold">
                                                <i class="fe fe-camera mr-1"></i> Capture Odometer Pic
                                            </button>
                                            
                                            <div class="row mt-3">
                                                <div class="col-6">
                                                    <div class="form-group mb-0">
                                                        <label class="small text-muted mb-1">Odo Reading (Last 4 digits)</label>
                                                        <input type="text" name="odometer_reading" class="form-control form-control-sm" placeholder="e.g. 1234" maxlength="4">
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="form-group mb-0">
                                                        <label class="small text-muted mb-1">Ticket / Parking Details</label>
                                                        <input type="text" name="ticket_details" class="form-control form-control-sm" placeholder="e.g. Mall Parking">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                        <button type="submit" id="check-in-btn" class="btn btn-lg btn-primary btn-block py-3 shadow-sm font-weight-bold" disabled>
                                            <i class="fe fe-lock mr-2"></i> Verify GPS & Photo
                                        </button>
                                    <?php elseif(!$attendance['check_out_time']): ?>
                                        <input type="hidden" name="attendance_id" value="<?php echo $attendance['id']; ?>">
                                        <button type="submit" id="check-out-btn" class="btn btn-lg btn-danger btn-block py-3 shadow-sm font-weight-bold" formaction="attendance?action=checkOut" disabled>
                                            <i class="fe fe-lock mr-2"></i> Verify GPS & Photo
                                        </button>
                                    <?php else: ?>
                                        <div class="p-3 bg-soft-success rounded-lg border border-success">
                                            <i class="fe fe-check-circle fe-20 text-success mb-1 d-block"></i>
                                            <h6 class="text-success font-weight-bold mb-0 small">Shift Completed</h6>
                                        </div>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8 mb-4">
                        <div class="card shadow-sm border-0 h-100 overflow-hidden border">
                            <div id="map-container" style="width: 100%; height: 100%; min-height: 450px; background: #f0f0f0;"></div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="card shadow-sm border-0 overflow-hidden mt-2">
                    <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Attendance Log</h5>
                        <span class="badge badge-pill badge-light"><?php echo date('F Y'); ?></span>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="bg-light text-muted small text-uppercase font-weight-bold">
                                    <tr>
                                        <th class="pl-4">Session Info</th>
                                        <th>Check-In</th>
                                        <th>Check-Out</th>
                                        <th class="pr-4 text-right">Verification</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($attendance): ?>
                                    <tr>
                                        <td class="pl-4">
                                            <div class="font-weight-600"><?php echo date('d M Y'); ?></div>
                                            <small class="text-muted italic"><?php echo $attendance['check_in_address']; ?></small>
                                        </td>
                                        <td>
                                            <div class="text-success font-weight-bold"><?php echo date('h:i A', strtotime($attendance['check_in_time'])); ?></div>
                                            <?php if($attendance['check_in_photo']): ?>
                                                <a href="<?php echo $attendance['check_in_photo']; ?>" target="_blank" class="small text-primary"><i class="fe fe-image mr-1"></i>View Photo</a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="<?php echo $attendance['check_out_time'] ? 'text-danger font-weight-bold' : 'text-muted italic'; ?>">
                                                <?php echo $attendance['check_out_time'] ? date('h:i A', strtotime($attendance['check_out_time'])) : 'Active Session'; ?>
                                            </div>
                                            <?php if($attendance['check_out_photo']): ?>
                                                <a href="<?php echo $attendance['check_out_photo']; ?>" target="_blank" class="small text-primary"><i class="fe fe-image mr-1"></i>View Photo</a>
                                            <?php endif; ?>
                                        </td>
                                        <td class="pr-4 text-right">
                                            <span class="badge <?php echo $attendance['check_out_time'] ? 'badge-success' : 'badge-primary'; ?> px-3 py-1">
                                                <?php echo $attendance['check_out_time'] ? 'Verified & Closed' : 'GPS Active'; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                        <tr><td colspan="4" class="text-center py-5 text-muted small">No attendance logs found for today. Get started by capturing your photo and GPS lock.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const latInput = document.getElementById('latitude');
        const lngInput = document.getElementById('longitude');
        const addrInput = document.getElementById('address');
        const photoDataInput = document.getElementById('photo_data');
        const gpsText = document.getElementById('gps-text');
        const accuracyText = document.getElementById('accuracy-text');
        const accuracyProgress = document.getElementById('accuracy-progress');
        const checkInBtn = document.getElementById('check-in-btn');
        const checkOutBtn = document.getElementById('check-out-btn');
        const gpsSpinner = document.getElementById('gps-spinner');
        
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const captureBtn = document.getElementById('capture-btn');
        const photoPreview = document.getElementById('photo-preview');
        const cameraOverlay = document.getElementById('camera-overlay');

        const videoOdo = document.getElementById('video-odo');
        const captureOdoBtn = document.getElementById('capture-odo-btn');
        const odoPreview = document.getElementById('odo-preview');
        const odometerDataInput = document.getElementById('odometer_data');

        let map, marker, platform;
        const isExecutive = <?php echo ($_SESSION['role'] == 'Executive') ? 'true' : 'false'; ?>;
        let isGpsLocked = false;
        let isPhotoCaptured = false;
        let isOdoCaptured = !isExecutive; 
        const REQUIRED_ACCURACY = 100;

        let map, marker, platform;
        let isGpsLocked = false;
        let isPhotoCaptured = false;
        let isOdoCaptured = !isExecutive; 
        const REQUIRED_ACCURACY = 100;

        // Initialize HERE Platform
        platform = new H.service.Platform({
            'apikey': window.HERE_API_KEY
        });
        const defaultLayers = platform.createDefaultLayers();
        map = new H.Map(
            document.getElementById('map-container'),
            defaultLayers.vector.normal.map,
            { zoom: 16, center: { lat: 20, lng: 77 } }
        );
        const mapEvents = new H.mapevents.MapEvents(map);
        new H.mapevents.Behavior(mapEvents);
        window.addEventListener('resize', () => map.getViewPort().resize());

        let currentFacingMode = { selfie: "user", odo: "environment" };
        let selfieStream = null;
        let odoStream = null;

        function startCamera(type, mode) {
            const constraints = { video: { facingMode: mode } };
            const vidElem = (type === 'selfie') ? video : videoOdo;

            if (type === 'selfie' && selfieStream) {
                selfieStream.getTracks().forEach(track => track.stop());
            } else if (type === 'odo' && odoStream) {
                odoStream.getTracks().forEach(track => track.stop());
            }

            navigator.mediaDevices.getUserMedia(constraints)
                .then(stream => {
                    vidElem.srcObject = stream;
                    if (type === 'selfie') {
                        selfieStream = stream;
                        cameraOverlay.classList.add('d-none');
                        captureBtn.disabled = false;
                    } else {
                        odoStream = stream;
                    }
                })
                .catch(err => {
                    console.error(`${type} camera error:`, err);
                    if (type === 'selfie') {
                        cameraOverlay.innerHTML = '<span class="small text-danger">Camera Access Denied</span>';
                    }
                });
        }

        window.switchCamera = function(type) {
            currentFacingMode[type] = (currentFacingMode[type] === "user") ? "environment" : "user";
            startCamera(type, currentFacingMode[type]);
        };

        // Initial Start
        startCamera('selfie', currentFacingMode.selfie);
        if (videoOdo) startCamera('odo', currentFacingMode.odo);

        captureBtn.addEventListener('click', () => {
            const context = canvas.getContext('2d');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            context.drawImage(video, 0, 0);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.5);
            if (dataUrl && dataUrl.length > 1000) {
                photoDataInput.value = dataUrl;
                photoPreview.src = dataUrl;
                photoPreview.style.display = 'block';
                video.style.display = 'none';
                isPhotoCaptured = true;
                validateCheckIn();
                captureBtn.innerHTML = '<i class="fe fe-refresh-cw mr-1"></i> Retake Photo';
                captureBtn.classList.replace('btn-outline-primary', 'btn-outline-secondary');
            }
        });

        if (captureOdoBtn) {
            const canvasOdo = document.getElementById('canvas-odo');
            captureOdoBtn.addEventListener('click', () => {
                const context = canvasOdo.getContext('2d');
                canvasOdo.width = videoOdo.videoWidth;
                canvasOdo.height = videoOdo.videoHeight;
                context.drawImage(videoOdo, 0, 0);
                const dataUrl = canvasOdo.toDataURL('image/jpeg', 0.5);
                if (dataUrl && dataUrl.length > 1000) {
                    odometerDataInput.value = dataUrl;
                    odoPreview.src = dataUrl;
                    odoPreview.style.display = 'block';
                    videoOdo.style.display = 'none';
                    isOdoCaptured = true;
                    validateCheckIn();
                    captureOdoBtn.innerHTML = '<i class="fe fe-refresh-cw mr-1"></i> Retake Odometer';
                }
            });
        }

        // Diagnostic: Log payload size before submission
        document.getElementById('attendance-form').addEventListener('submit', (e) => {
            const photoSize = photoDataInput.value.length;
            const odoSize = odometerDataInput.value.length;
            console.log(`Submitting Attendance. Photo: ${Math.round(photoSize/1024)}KB, Odometer: ${Math.round(odoSize/1024)}KB. Total: ${Math.round((photoSize+odoSize)/1024)}KB`);
        });

        function validateCheckIn() {
            if (isGpsLocked && isPhotoCaptured && isOdoCaptured) {
                if (checkInBtn) {
                    checkInBtn.disabled = false;
                    checkInBtn.innerHTML = '<i class="fe fe-check mr-2"></i> Confirm Check-In';
                    checkInBtn.classList.replace('btn-primary', 'btn-success');
                }
                if (checkOutBtn) {
                    checkOutBtn.disabled = false;
                    checkOutBtn.innerHTML = '<i class="fe fe-check mr-2"></i> Confirm Check-Out';
                    checkOutBtn.classList.replace('btn-danger', 'btn-success');
                }
            }
        }

        function monitorPrecision() {
            navigator.geolocation.watchPosition(pos => {
                const lat = pos.coords.latitude;
                const lng = pos.coords.longitude;
                const acc = pos.coords.accuracy;

                let progress = acc < 100 ? 100 : (acc < 300 ? 80 : (acc < 1000 ? 50 : 20));
                accuracyProgress.style.width = progress + "%";
                accuracyText.textContent = `Accuracy: ±${Math.round(acc)}m`;

                if (acc <= REQUIRED_ACCURACY) {
                    latInput.value = lat;
                    lngInput.value = lng;
                    isGpsLocked = true;
                    gpsText.innerHTML = '<i class="fe fe-check-circle text-success mr-2"></i>Pinpoint Lock Confirmed';
                    accuracyProgress.classList.replace('bg-warning', 'bg-success');
                    gpsSpinner.classList.add('d-none');
                    validateCheckIn();

                    // Update Map
                    map.setCenter({ lat, lng });
                    if (!marker) {
                        marker = new H.map.Marker({ lat, lng });
                        map.addObject(marker);
                    } else {
                        marker.setGeometry({ lat, lng });
                    }

                    if (!addrInput.value) {
                        fetch(`https://revgeocode.search.hereapi.com/v1/revgeocode?at=${lat},${lng}&lang=en-US&apiKey=${window.HERE_API_KEY}`)
                            .then(r => r.json())
                            .then(d => {
                                const addr = d.items[0]?.address.label || "GPS Tagged Location";
                                addrInput.value = addr;
                            });
                    }
                } else {
                    gpsText.textContent = "Refining Satellite Signal...";
                    accuracyProgress.classList.replace('bg-success', 'bg-warning');
                }
            }, null, { enableHighAccuracy: true, maximumAge: 0 });
        }

        monitorPrecision();

        // Clock
        setInterval(() => {
            document.getElementById('live-clock').textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
        }, 1000);
    });
</script>

<style>
.bg-soft-primary { background-color: rgba(67, 97, 238, 0.1); }
.bg-soft-success { background-color: rgba(40, 167, 69, 0.1); }
.font-weight-600 { font-weight: 600; }
.italic { font-style: italic; }
.progress-bar { transition: width 0.5s ease; }
</style>

<?php include 'layout/footer.php'; ?>
